@extends(backpack_view('blank'))

@section('header')
<section class="container-fluid">
    {{-- <h2>
        <i
            class="la la-money-check text-{{ request('payout_type', 'pending') === 'completed' ? 'success' : 'warning' }}"></i>
        {{ request('payout_type', 'pending') === 'completed' ? 'Completed Payout' : 'Pending Payout' }}
        <small class="d-none d-md-inline">
            {{ request('payout_type', 'pending') === 'completed' ? '(Processed)' : '(Awaiting Payout)' }}
        </small>
    </h2> --}}
</section>
@endsection
@push('after_styles')
<link rel="stylesheet" href="https://unpkg.com/ag-grid-community/styles/ag-theme-quartz.css">

<style>
    .ag-theme-quartz .center-header .ag-header-cell-label {
        justify-content: center !important;
    }
</style>
@endpush

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">

            {{-- HEADER --}}
            <div
                class="card-header bg-gradient-{{ request('payout_type', 'pending') === 'completed' ? 'success' : 'warning' }} d-flex justify-content-between align-items-center flex-wrap gap-3">
                <h2 class="card-title mb-0 fw-bold text-black text-nowrap">
                    Finance Payout - {{ request('payout_type', 'pending') === 'completed' ? 'Completed' : 'Pending' }}
                    Dashboard
                </h2>

                <div class="d-flex align-items-center gap-3 flex-wrap">
                    <div class="d-flex align-items-center gap-2">
                        <label class="text-black mb-0 text-nowrap">Payout Status:</label>
                        <select id="payout_type" class="form-control form-select" style="min-width: 220px;">
                            <option value="pending" {{ request('payout_type', 'pending' )==='pending' ? 'selected' : ''
                                }}>
                                Pending Payout
                            </option>
                            <option value="completed" {{ request('payout_type')==='completed' ? 'selected' : '' }}>
                                Completed Payout
                            </option>
                        </select>
                    </div>

                    @if(request('payout_type', 'pending') === 'completed')
                    <div class="d-flex align-items-center gap-2">
                        <label class="text-black mb-0 text-nowrap">Difference Filter:</label>
                        <select id="status_filter" class="form-control" style="min-width: 180px;">
                            <option value="all" {{ request('status_filter', 'all' )==='all' ? 'selected' : '' }}>All
                            </option>
                            <option value="short" {{ request('status_filter')==='short' ? 'selected' : '' }}>Short
                            </option>
                            <option value="excess" {{ request('status_filter')==='excess' ? 'selected' : '' }}>Excess
                            </option>
                            <option value="reconciled" {{ request('status_filter')==='reconciled' ? 'selected' : '' }}>
                                Reconciled</option>
                        </select>
                    </div>
                    @endif
                </div>
            </div>

            {{-- BODY --}}
            <div class="card-body p-0 bg-light">

                {{-- TOOLBAR --}}
                <div
                    class="d-flex justify-content-between align-items-center flex-wrap gap-3 p-3 border-bottom bg-white">
                    <div class="d-flex align-items-center gap-2 flex-wrap">
                        <input type="text" id="quickFilter" class="form-control" style="width: 360px; min-width: 260px;"
                            placeholder="Smart Search...">
                        <button id="resetAll" class="btn btn-outline-danger btn-sm">Reset</button>
                    </div>
                    <div class="d-flex gap-2 flex-wrap justify-content-center">



                        <button id="btnDefaultHeaders" class="btn btn-secondary btn-sm text-nowrap">
                            Default Headers
                        </button>

                        <div class="position-relative">
                            <button id="btnCustomiseHeaders" class="btn btn-danger btn-sm text-nowrap">
                                Customise Headers
                            </button>

                            <!-- Customise Bubble -->
                            <div id="columnBubble" style="
                                display:none;
                                position:absolute;
                                top:110%;
                                left:0;
                                width:260px;
                                background:#fff;
                                border:1px solid #ddd;
                                border-radius:6px;
                                box-shadow:0 8px 20px rgba(0,0,0,.15);
                                z-index:9999;
                            ">
                                <div class="d-flex justify-content-between px-2 py-1 border-bottom">
                                    <strong style="font-size:13px;">Customise Headers</strong>
                                    <button id="closeColumnBubble"
                                        class="btn btn-sm btn-link text-danger p-0">✕</button>
                                </div>

                                <div style="max-height:260px; overflow:auto;">
                                    <table class="table table-sm mb-0">
                                        <tbody id="columnBubbleBody"></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <button id="btnAllHeaders" class="btn btn-info btn-sm text-nowrap">
                            All Headers
                        </button>



                    </div>




                    <div class="d-flex gap-2 flex-wrap">
                        <button id="exportCsv" class="btn btn-sm text-nowrap d-flex align-items-center gap-2">
                            <img src="{{ asset('images/export-excel.png') }}" alt="Excel"
                                style="height:30px; width:auto;">
                        </button>

                        <button id="exportExcel" class="btn btn-sm text-nowrap d-flex align-items-center gap-2">
                            <img src="{{ asset('images/export-pdf.png') }}" alt="PDF" style="height:30px; width:auto;">
                        </button>
                    </div>
                </div>

                {{-- GRID --}}
                <div id="myGrid" class="ag-theme-quartz" style="height: calc(93vh - 260px); width: 100%;"></div>
            </div>

            @if(session('info'))
            <div class="card-footer text-center py-4 text-muted">
                {{ session('info') }}
            </div>
            @endif
        </div>
    </div>
</div>
@endsection

@push('after_styles')
<link rel="stylesheet" href="https://unpkg.com/ag-grid-community/styles/ag-theme-quartz.css">
@endpush

@push('after_scripts')
<script src="https://unpkg.com/ag-grid-community/dist/ag-grid-community.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>

<script>
    // ────────────────────────────────────────────────
    // ALL_COLUMNS from controller → $gridConfig['columns']
    // ────────────────────────────────────────────────
    const ALL_COLUMNS = @json($gridConfig['columns'] ?? []);

    function getCols(fields) {
        return ALL_COLUMNS.filter(col => fields.includes(col.field));
    }

    let gridApi;

    // ────────────────────────────────────────────────
    // Default visible fields → only Y marked ones
    // ────────────────────────────────────────────────
    const DEFAULT_VISIBLE_FIELDS = [
        // Primary - Y (both pending & completed)
        'serial_no',
        'booking_no',
        'created_at',           // Entry Date
        'booking_date',
        'days_count',           // Booking Age
        'inv_no',               // Invoice No.
        'inv_date',             // Invoice Date

        // Customer - Y
        'name',                 // Customer Name
        'mobile',               // Contact No.
        'branch_name',
        'location_name',

        // Vehicle - Y
        'model',
        'variant',
        'color',
        'seating',

        // Booking Detail - Y
        'consultant',           // Sales Consultant
        'finance_mode_final',   // Finance Mode (Final)
        'financier',            // Financier
        'financier_short',      // Financier Short Name

        // Payout Category & related - Y (both views)
        'payout_category',      // Payout Category *
        'do_number',            // DO Number *
        'loan_amount_dealer',   // Loan Amount (Dealer Entry) *
        'expected_payout_percent', // Expected Payout % *
        'expected_payout_without_gst', // Expected Payout % without GST
        'expected_payout_amount_without_gst', // Expected Payout Amount without GST

        // Action (always visible)
        'action'
    ];

    // ────────────────────────────────────────────────
    // Grouped columns with pinning & centering
    // ────────────────────────────────────────────────
    const columnGroups = [
        {
            headerName: 'Primary',
            headerClass: 'ag-header-center',
            children: getCols([
                'serial_no',
                'booking_no',
                'created_at',
                'booking_date',
                'days_count',
                'inv_no',
                'inv_date'
            ]).map(col => {
                if (col.field === 'serial_no' || col.field === 'booking_no') {
                    col.pinned = 'left';
                }
                return col;
            })
        },
        {
            headerName: 'Customer',
            headerClass: 'ag-header-center',
            children: getCols([
                'receipt_no',
                'receipt_date',
                'name',
                'mobile',
                'alt_mobile',
                'pan_no',
                'adhar_no',
                'gstn',
                'branch_name',
                'location_name'
            ])
        },
        {
            headerName: 'Vehicle',
            headerClass: 'ag-header-center',
            children: getCols([
                'segment',
                'model',
                'variant',
                'color',
                'seating',
                'chasis_no'
            ])
        },
        {
            headerName: 'Booking Detail',
            headerClass: 'ag-header-center',
            children: getCols([
                'consultant',
                'delivery_date',
                'finmode',
                'financier',
                'loan_status'
            ])
        },
        {
            headerName: 'Insurance',
            headerClass: 'ag-header-center',
            children: getCols([
                'finance_payout_category',
                'do_number',
                'loan_amount_payout',
                'expected_payout_pct',
                'expected_payout_without_gst',
                'expected_payout_amount_without_gst'
            ])
        },
        {
            headerName: 'Action',
            headerClass: 'ag-header-center',
            children: getCols(['action']).map(col => {
                col.pinned = 'right';
                col.cellRenderer = 'htmlRenderer';
                col.autoHeight = true;
                col.cellClass = 'text-center p-0';
                return col;
            })
        }
    ];

    const gridOptions = {
        columnDefs: columnGroups,
        rowData: @json($gridConfig['data'] ?? []),
        pagination: true,
        paginationPageSize: 50,
        paginationPageSizeSelector: [20, 50, 100, 200],
        rowHeight: 30,
        animateRows: true,

        defaultColDef: {
            sortable: true,
            filter: true,
            resizable: true,
            headerClass: 'center-header',
            cellStyle: { textAlign: 'center' },
            suppressHeaderMenuButton: false,
        },

        components: {
            htmlRenderer: params => params.value || '',
        },

        onGridReady: params => {
            gridApi = params.api;

            const allFields = [];
            columnGroups.forEach(group => {
                if (group.children) {
                    group.children.forEach(child => {
                        if (child.field) allFields.push(child.field);
                    });
                }
            });

            gridApi.setColumnsVisible(allFields, false);
            gridApi.setColumnsVisible(DEFAULT_VISIBLE_FIELDS, true);

            setTimeout(() => {
                const visibleIds = gridApi.getAllDisplayedColumns().map(c => c.getColId());
                gridApi.autoSizeColumns(visibleIds, false);
            }, 400);
        }
    };

    // ────────────────────────────────────────────────
    // Customise Headers – grouped + sync
    // ────────────────────────────────────────────────
    function openColumnBubble() {
        const bubble = document.getElementById('columnBubble');
        const tbody  = document.getElementById('columnBubbleBody');
        if (!gridApi || !bubble || !tbody) return;

        tbody.innerHTML = '';

        columnGroups.forEach(group => {
            const groupName = group.headerName;
            const children  = group.children || [];

            if (groupName === 'Action') return;

            const groupTr = document.createElement('tr');
            groupTr.style.background = '#f0f0f0';

            const groupCheckTd = document.createElement('td');
            groupCheckTd.style.width = '30px';
            groupCheckTd.className = 'text-center';

            const groupCheckbox = document.createElement('input');
            groupCheckbox.type = 'checkbox';

            const fields = children.map(c => c.field).filter(Boolean);
            const visibleCount = fields.filter(f => {
                const col = gridApi.getColumn(f);
                return col && col.isVisible();
            }).length;

            groupCheckbox.checked = visibleCount === fields.length && visibleCount > 0;
            groupCheckbox.indeterminate = visibleCount > 0 && visibleCount < fields.length;

            if (groupName === 'Primary') {
                groupCheckbox.checked = true;
                groupCheckbox.disabled = true;
            }

            groupCheckbox.addEventListener('change', () => {
                gridApi.setColumnsVisible(fields, groupCheckbox.checked);
                tbody.querySelectorAll(`tr[data-group="${groupName}"] input`)
                    .forEach(cb => cb.checked = groupCheckbox.checked);
            });

            groupCheckTd.appendChild(groupCheckbox);

            const groupLabelTd = document.createElement('td');
            groupLabelTd.colSpan = 2;
            groupLabelTd.innerHTML = `<strong>${groupName}</strong>`;

            groupTr.appendChild(groupCheckTd);
            groupTr.appendChild(groupLabelTd);
            tbody.appendChild(groupTr);

            children.forEach(child => {
                if (!child.field) return;

                const tr = document.createElement('tr');
                tr.dataset.group = groupName;

                const tdCheck = document.createElement('td');
                tdCheck.style.paddingLeft = '40px';
                tdCheck.className = 'text-center';

                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';

                const col = gridApi.getColumn(child.field);
                checkbox.checked = col ? col.isVisible() : false;

                if (groupName === 'Primary') {
                    checkbox.disabled = true;
                    checkbox.checked = true;
                }

                checkbox.addEventListener('change', () => {
                    gridApi.setColumnsVisible([child.field], checkbox.checked);
                });

                tdCheck.appendChild(checkbox);

                const tdLabel = document.createElement('td');
                tdLabel.innerText = child.headerName;

                tr.appendChild(tdCheck);
                tr.appendChild(tdLabel);
                tbody.appendChild(tr);
            });
        });

        bubble.style.display = 'block';
    }

    // ────────────────────────────────────────────────
    // Event Listeners
    // ────────────────────────────────────────────────
    document.getElementById('btnCustomiseHeaders')?.addEventListener('click', e => {
        e.stopPropagation();
        openColumnBubble();
    });

    document.getElementById('closeColumnBubble')?.addEventListener('click', () => {
        document.getElementById('columnBubble').style.display = 'none';
    });

    document.getElementById('columnBubble')?.addEventListener('click', e => e.stopPropagation());

    document.addEventListener('click', () => {
        const bubble = document.getElementById('columnBubble');
        if (bubble) bubble.style.display = 'none';
    });

    document.getElementById('btnAllHeaders')?.addEventListener('click', () => {
        const allFields = [];
        columnGroups.forEach(group => {
            if (group.children) {
                group.children.forEach(c => {
                    if (c.field) allFields.push(c.field);
                });
            }
        });
        gridApi.setColumnsVisible(allFields, true);
        setTimeout(() => {
            const visibleIds = gridApi.getAllDisplayedColumns().map(c => c.getColId());
            gridApi.autoSizeColumns(visibleIds, false);
        }, 200);
    });

    document.getElementById('btnDefaultHeaders')?.addEventListener('click', () => {
        const allFields = [];
        columnGroups.forEach(group => {
            if (group.children) {
                group.children.forEach(c => {
                    if (c.field) allFields.push(c.field);
                });
            }
        });

        gridApi.setColumnsVisible(allFields, false);
        gridApi.setColumnsVisible(DEFAULT_VISIBLE_FIELDS, true);

        setTimeout(() => {
            const visibleIds = gridApi.getAllDisplayedColumns().map(c => c.getColId());
            gridApi.autoSizeColumns(visibleIds, false);
        }, 200);
    });

    document.addEventListener('DOMContentLoaded', () => {
        const gridDiv = document.querySelector('#myGrid');
        gridApi = agGrid.createGrid(gridDiv, gridOptions);

        document.getElementById('quickFilter')?.addEventListener('input', e => {
            gridApi.setGridOption('quickFilterText', e.target.value);
        });

        document.getElementById('resetAll')?.addEventListener('click', () => {
            gridApi.setFilterModel(null);
            gridApi.setGridOption('quickFilterText', '');
            document.getElementById('quickFilter').value = '';
        });

        // Payout Type switch (Pending ↔ Completed)
        document.getElementById('payout_type')?.addEventListener('change', function() {
            const url = new URL(window.location);
            url.searchParams.set('payout_type', this.value);
            url.searchParams.delete('status_filter');
            window.location = url;
        });

        // Difference Filter (for Completed only)
        document.getElementById('status_filter')?.addEventListener('change', function() {
            const url = new URL(window.location);
            if (this.value === 'all') {
                url.searchParams.delete('status_filter');
            } else {
                url.searchParams.set('status_filter', this.value);
            }
            window.location = url;
        });

        // Excel Export
        document.getElementById('exportCsv')?.addEventListener('click', () => {
            const visibleColumns = gridApi.getAllDisplayedColumns()
                .map(col => col.getColDef())
                .filter(col => col.field && col.field !== 'action');

            const rows = [];
            gridApi.forEachNodeAfterFilterAndSort(node => {
                const row = {};
                visibleColumns.forEach(col => {
                    row[col.headerName] = node.data[col.field] ?? '';
                });
                rows.push(row);
            });

            const worksheet = XLSX.utils.json_to_sheet(rows);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, 'Finance Payout');
            XLSX.writeFile(workbook, `finance-payout-${new Date().toISOString().slice(0,10)}.xlsx`);
        });

        // PDF Export
        document.getElementById('exportExcel')?.addEventListener('click', () => {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('l', 'pt', 'a4');

            const visibleColumns = gridApi.getAllDisplayedColumns()
                .map(col => col.getColDef())
                .filter(col => col.field && col.field !== 'action');

            const exportCols = visibleColumns.map(col => ({
                header: col.headerName,
                dataKey: col.field
            }));

            const rows = [];
            gridApi.forEachNodeAfterFilterAndSort(node => {
                const row = {};
                visibleColumns.forEach(col => {
                    row[col.field] = node.data[col.field];
                });
                rows.push(row);
            });

            doc.text('Finance Payout Report', 40, 30);
            doc.autoTable({
                columns: exportCols,
                body: rows,
                startY: 50,
                styles: { fontSize: 8 },
                headStyles: { fillColor: [13, 110, 253] },
            });

            doc.save('finance-payout.pdf');
        });
    });
</script>
@endpush