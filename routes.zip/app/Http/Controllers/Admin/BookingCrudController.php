<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\BookingRequest;
use App\Models\Booking;
use App\Models\XlFinancier;
use App\Models\Xl_DSA_Master;
use App\Models\EnumMaster;
use App\Helpers\XpricingHelper;
use App\Helpers\CommonHelper;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;

class BookingCrudController extends CrudController
{
    use \Backpack\CRUD\app\Http\Traits\SaveActions;

    public static function routes($name = null, $segment = null, $gate = null)
    {
        Route::crud($name ?? 'booking', $segment ?? 'booking', $gate ?? 'manage_bookings');
    }

    /**
     * Perform any database calls required to display the list view.
     */
    public function setup()
    {
        CRUD::setModel(\App\Models\Booking::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/booking');
        CRUD::setEntityNameStrings('booking', 'bookings');
    }

    /**
     * Perform any database calls required to display the list view.
     */
    protected function setupListOperation()
    {
        CRUD::setFromDb();
        CRUD::column('name')->label('Customer Name');
        CRUD::column('mobile');
        CRUD::column('booking_amount')->prefix('₹ ');
        CRUD::column('branch')->label('Branch');
        CRUD::column('booking_date');
        CRUD::column('status');
        CRUD::column('created_at')->type('datetime');

        /**
         * Columns can be defined using the fluent syntax or array syntax:
         * - CRUD::column('price')->type('number');
         * - CRUD::addColumn(['name' => 'price', 'type' => 'number']);
         */
    }

    /**
     * Perform any database calls required to display the create form.
     */
    protected function setupCreateOperation()
    {
        CRUD::setValidation(BookingRequest::class);

        // ============================================================
        // SECTION 1: HEADER - FREE MODERN LOOK (Flatpickr + Select2)
        // ============================================================
        CRUD::addField([
            'name' => 'free_assets',
            'type' => 'custom_html',
            'value' => view('booking.partials.free_assets')->render(),
        ]);

        // ============================================================
        // SECTION 2: PAYMENT DETAILS
        // ============================================================
        CRUD::addField([
            'name' => 'separator_payment',
            'type' => 'custom_html',
            'value' => '<div class="alert alert-info"><strong>Payment Details</strong></div>',
        ]);

        CRUD::addField([
            'name' => 'customer_type',
            'type' => 'select_from_array',
            'options' => ['Active' => 'Actual', 'Dummy' => 'Dummy'],
            'label' => 'Customer Type *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'customer_type',
                'class' => 'form-control form-control-lg',
                'onchange' => 'toggleCustomerFields()'
            ]
        ]);

        CRUD::addField([
            'name' => 'customer_cat',
            'type' => 'select_from_array',
            'options' => [
                'Individual' => 'Individual',
                'CSD' => 'CSD',
                'Firm' => 'Firm'
            ],
            'label' => 'Customer Category *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'customer_cat',
                'class' => 'form-control form-control-lg',
                'onchange' => 'toggleCustomerFields()'
            ]
        ]);

        CRUD::addField([
            'name' => 'booking_date',
            'type' => 'text',
            'label' => 'Booking Date *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'booking_date',
                'class' => 'form-control flatpickr-date',
                'placeholder' => 'dd-mmm-yyyy',
                'autocomplete' => 'off'
            ]
        ]);

        CRUD::addField([
            'name' => 'col_type',
            'type' => 'select_from_array',
            'options' => [
                1 => 'Receipt',
                2 => 'Field Collection (Sales Team)',
                3 => 'Field Collection (DSA)',
                4 => 'Used Car Purchase'
            ],
            'label' => 'Collection Type *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'col_type',
                'class' => 'form-control form-control-lg',
                'onchange' => 'toggleCollectionFields()'
            ]
        ]);

        CRUD::addField([
            'name' => 'booking_amount',
            'type' => 'number',
            'label' => 'Booking Amount *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'booking_amount',
                'class' => 'form-control form-control-lg',
                'step' => '0.01',
                'min' => '0'
            ]
        ]);

        CRUD::addField([
            'name' => 'receipt_no',
            'type' => 'text',
            'label' => 'Receipt / Voucher No. *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'receipt_no',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Enter receipt number'
            ]
        ]);

        CRUD::addField([
            'name' => 'receipt_date',
            'type' => 'text',
            'label' => 'Receipt Date *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'receipt_date',
                'class' => 'form-control flatpickr-date',
                'placeholder' => 'dd-mmm-yyyy',
                'autocomplete' => 'off'
            ]
        ]);

        CRUD::addField([
            'name' => 'amount_proof',
            'type' => 'upload',
            'label' => 'Upload Payment Proof',
            'upload' => true,
            'disk' => 'public',
            'wrapper' => ['class' => 'form-group col-md-3'],
        ]);

        // ============================================================
        // SECTION 3: CUSTOMER DETAILS
        // ============================================================
        CRUD::addField([
            'name' => 'separator_customer',
            'type' => 'custom_html',
            'value' => '<div class="alert alert-info"><strong>Customer Details</strong></div>',
        ]);

        CRUD::addField([
            'name' => 'name',
            'type' => 'text',
            'label' => 'Customer Name *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'name',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Full name'
            ]
        ]);

        CRUD::addField([
            'name' => 'mobile',
            'type' => 'text',
            'label' => 'Mobile Number *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'mobile',
                'class' => 'form-control form-control-lg phone-mask',
                'placeholder' => '10 digit mobile',
                'data-mask' => '9999999999'
            ]
        ]);

        CRUD::addField([
            'name' => 'alt_mobile',
            'type' => 'text',
            'label' => 'Alternate Mobile',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'alt_mobile',
                'class' => 'form-control form-control-lg phone-mask',
                'placeholder' => '10 digit mobile',
                'data-mask' => '9999999999'
            ]
        ]);

        CRUD::addField([
            'name' => 'customer_dob',
            'type' => 'text',
            'label' => 'Date of Birth',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'customer_dob',
                'class' => 'form-control flatpickr-date',
                'placeholder' => 'dd-mmm-yyyy',
                'autocomplete' => 'off'
            ]
        ]);

        CRUD::addField([
            'name' => 'customer_age',
            'type' => 'number',
            'label' => 'Age',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'customer_age',
                'class' => 'form-control form-control-lg',
                'readonly' => 'readonly'
            ]
        ]);

        CRUD::addField([
            'name' => 'gender',
            'type' => 'select_from_array',
            'options' => ['Male' => 'Male', 'Female' => 'Female', 'Other' => 'Other'],
            'label' => 'Gender',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'gender',
                'class' => 'form-control form-control-lg'
            ]
        ]);

        CRUD::addField([
            'name' => 'occupation',
            'type' => 'text',
            'label' => 'Occupation',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'occupation',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Occupation'
            ]
        ]);

        CRUD::addField([
            'name' => 'pan_no',
            'type' => 'text',
            'label' => 'PAN Number',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'pan_no',
                'class' => 'form-control form-control-lg pan-mask',
                'placeholder' => 'XXXXXXXXXX',
                'data-mask' => 'AAAAA9999A'
            ]
        ]);

        CRUD::addField([
            'name' => 'aadhar_no',
            'type' => 'text',
            'label' => 'Aadhar Number',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'aadhar_no',
                'class' => 'form-control form-control-lg aadhar-mask',
                'placeholder' => '12 digit aadhar',
                'data-mask' => '9999999999999'
            ]
        ]);

        CRUD::addField([
            'name' => 'gstn',
            'type' => 'text',
            'label' => 'GST Number',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'gstn',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'GST Number'
            ]
        ]);

        CRUD::addField([
            'name' => 'not_required_gst',
            'type' => 'checkbox',
            'label' => 'GST Not Required',
            'wrapper' => ['class' => 'form-group col-md-3'],
        ]);

        CRUD::addField([
            'name' => 'care_of',
            'type' => 'select_from_array',
            'options' => ['Father' => 'Father', 'Mother' => 'Mother', 'Spouse' => 'Spouse', 'Other' => 'Other'],
            'label' => 'Care of',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'care_of',
                'class' => 'form-control form-control-lg'
            ]
        ]);

        CRUD::addField([
            'name' => 'care_of_name',
            'type' => 'text',
            'label' => 'Care of Name',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'care_of_name',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Name'
            ]
        ]);

        // ============================================================
        // SECTION 4: REFERRED BY DETAILS
        // ============================================================
        CRUD::addField([
            'name' => 'separator_referred',
            'type' => 'custom_html',
            'value' => '<div class="alert alert-info"><strong>Referred By Details</strong></div>',
        ]);

        CRUD::addField([
            'name' => 'referred_by',
            'type' => 'select_from_array',
            'options' => ['Existing Customer' => 'Existing Customer', 'DSA' => 'DSA', 'Walk In' => 'Walk In', 'Other' => 'Other'],
            'label' => 'Referred By',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'referred_by',
                'class' => 'form-control form-control-lg',
                'onchange' => 'toggleFields()'
            ]
        ]);

        CRUD::addField([
            'name' => 'ref_customer_name',
            'type' => 'text',
            'label' => 'Ref. Customer Name',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'ref_customer_name_wrapper'],
            'attributes' => [
                'id' => 'ref_customer_name',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Customer name'
            ]
        ]);

        CRUD::addField([
            'name' => 'ref_mobile_no',
            'type' => 'text',
            'label' => 'Ref. Mobile Number',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'ref_mobile_no_wrapper'],
            'attributes' => [
                'id' => 'ref_mobile_no',
                'class' => 'form-control form-control-lg phone-mask',
                'placeholder' => '10 digit mobile',
                'data-mask' => '9999999999'
            ]
        ]);

        CRUD::addField([
            'name' => 'ref_existing_model',
            'type' => 'relationship',
            'label' => 'Ref. Existing Model',
            'model' => 'App\Models\Model',
            'attribute' => 'name',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'ref_existing_model_wrapper'],
        ]);

        CRUD::addField([
            'name' => 'ref_variant',
            'type' => 'text',
            'label' => 'Ref. Variant',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'ref_variant_wrapper'],
            'attributes' => [
                'id' => 'ref_variant',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Variant'
            ]
        ]);

        CRUD::addField([
            'name' => 'ref_chassis_reg_no',
            'type' => 'text',
            'label' => 'Ref. Chassis / Reg. No.',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'ref_chassis_reg_no_wrapper'],
            'attributes' => [
                'id' => 'ref_chassis_reg_no',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Chassis or registration'
            ]
        ]);

        CRUD::addField([
            'name' => 'dsa_details',
            'type' => 'select',
            'label' => 'DSA Details',
            'model' => 'App\Models\Xl_DSA_Master',
            'attribute' => 'name',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'dsa_details_wrapper'],
            'attributes' => [
                'id' => 'dsa_details',
                'class' => 'form-control form-control-lg select2',
            ]
        ]);

        // ============================================================
        // SECTION 5: PURCHASE TYPE DETAILS
        // ============================================================
        CRUD::addField([
            'name' => 'separator_purchase',
            'type' => 'custom_html',
            'value' => '<div class="alert alert-info"><strong>Purchase Type Details</strong></div>',
        ]);

        CRUD::addField([
            'name' => 'booking_mode',
            'type' => 'select_from_array',
            'options' => [
                'New' => 'New',
                'Exchange' => 'Exchange',
                'Used Car Purchase' => 'Used Car Purchase'
            ],
            'label' => 'Booking Mode *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'booking_mode',
                'class' => 'form-control form-control-lg',
                'onchange' => 'togglePurchaseFields()'
            ]
        ]);

        // ---- New Vehicle Fields ----
        CRUD::addField([
            'name' => 'segment_id',
            'type' => 'select',
            'label' => 'Segment *',
            'model' => 'App\Models\Segment',
            'attribute' => 'name',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'segment_wrapper'],
            'attributes' => [
                'id' => 'segment_id',
                'class' => 'form-control form-control-lg select2',
                'onchange' => 'updateModels()'
            ]
        ]);

        CRUD::addField([
            'name' => 'model',
            'type' => 'select',
            'label' => 'Model *',
            'model' => 'App\Models\Model',
            'attribute' => 'name',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'model_wrapper'],
            'attributes' => [
                'id' => 'model',
                'class' => 'form-control form-control-lg select2',
                'onchange' => 'updateVariants()'
            ]
        ]);

        CRUD::addField([
            'name' => 'variant',
            'type' => 'select',
            'label' => 'Variant *',
            'model' => 'App\Models\Variant',
            'attribute' => 'name',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'variant_wrapper'],
            'attributes' => [
                'id' => 'variant',
                'class' => 'form-control form-control-lg select2'
            ]
        ]);

        CRUD::addField([
            'name' => 'color',
            'type' => 'select',
            'label' => 'Color',
            'model' => 'App\Models\Color',
            'attribute' => 'name',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'color',
                'class' => 'form-control form-control-lg select2'
            ]
        ]);

        CRUD::addField([
            'name' => 'seating',
            'type' => 'number',
            'label' => 'Seating',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'seating',
                'class' => 'form-control form-control-lg',
                'readonly' => 'readonly'
            ]
        ]);

        CRUD::addField([
            'name' => 'manufacturing_year',
            'type' => 'text',
            'label' => 'Manufacturing Year',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'manufacturing_year',
                'class' => 'form-control form-control-lg',
                'readonly' => 'readonly'
            ]
        ]);

        CRUD::addField([
            'name' => 'accessories',
            'type' => 'select',
            'label' => 'Accessories',
            'multiple' => true,
            'model' => 'App\Models\Accessory',
            'attribute' => 'name',
            'wrapper' => ['class' => 'form-group col-md-6', 'id' => 'accessories_wrapper'],
            'attributes' => [
                'id' => 'accessories',
                'class' => 'form-control form-control-lg select2',
                'onchange' => 'updateAccessoriesAmount()'
            ]
        ]);

        CRUD::addField([
            'name' => 'apack_amount',
            'type' => 'number',
            'label' => 'Accessories Pack Amount',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'apack_amount',
                'class' => 'form-control form-control-lg',
                'readonly' => 'readonly',
                'step' => '0.01'
            ]
        ]);

        CRUD::addField([
            'name' => 'expected_price',
            'type' => 'number',
            'label' => 'Expected Price *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'expected_price',
                'class' => 'form-control form-control-lg',
                'step' => '0.01',
                'onchange' => 'calculatePriceGap()'
            ]
        ]);

        CRUD::addField([
            'name' => 'offered_price',
            'type' => 'number',
            'label' => 'Offered Price',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'offered_price',
                'class' => 'form-control form-control-lg',
                'step' => '0.01',
                'onchange' => 'calculatePriceGap()'
            ]
        ]);

        CRUD::addField([
            'name' => 'difference',
            'type' => 'number',
            'label' => 'Price Difference',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'difference',
                'class' => 'form-control form-control-lg',
                'readonly' => 'readonly',
                'step' => '0.01'
            ]
        ]);

        CRUD::addField([
            'name' => 'exchange_bonus',
            'type' => 'number',
            'label' => 'Exchange Bonus',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'exchange_bonus_wrapper'],
            'attributes' => [
                'id' => 'exchange_bonus',
                'class' => 'form-control form-control-lg',
                'step' => '0.01'
            ]
        ]);

        CRUD::addField([
            'name' => 'make_order',
            'type' => 'checkbox',
            'label' => 'Make Order',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'make_order_wrapper'],
        ]);

        CRUD::addField([
            'name' => 'expected_del_date',
            'type' => 'text',
            'label' => 'Expected Delivery Date',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'expected_del_date',
                'class' => 'form-control flatpickr-date',
                'placeholder' => 'dd-mmm-yyyy',
                'autocomplete' => 'off'
            ]
        ]);

        // ---- Exchange / Used Car Purchase Fields ----
        CRUD::addField([
            'name' => 'vh_id',
            'type' => 'text',
            'label' => 'Vehicle ID',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'vh_id_wrapper'],
            'attributes' => [
                'id' => 'vh_id',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Vehicle ID'
            ]
        ]);

        CRUD::addField([
            'name' => 'ref_existing_model',
            'type' => 'text',
            'label' => 'Existing Model',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'ref_existing_model_wrapper2'],
            'attributes' => [
                'id' => 'ref_existing_model2',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Model'
            ]
        ]);

        CRUD::addField([
            'name' => 'registration_no',
            'type' => 'text',
            'label' => 'Registration Number',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'registration_no_wrapper'],
            'attributes' => [
                'id' => 'registration_no',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Registration number'
            ]
        ]);

        CRUD::addField([
            'name' => 'chassis',
            'type' => 'text',
            'label' => 'Chassis Number',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'chassis_wrapper'],
            'attributes' => [
                'id' => 'chassis',
                'class' => 'form-control form-control-lg select2',
                'placeholder' => 'Chassis number'
            ]
        ]);

        CRUD::addField([
            'name' => 'odometer_reading',
            'type' => 'number',
            'label' => 'Odometer Reading (KMs)',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'odometer_reading_wrapper'],
            'attributes' => [
                'id' => 'odometer_reading',
                'class' => 'form-control form-control-lg',
                'min' => '0'
            ]
        ]);

        // ============================================================
        // SECTION 6: FINANCE DETAILS
        // ============================================================
        CRUD::addField([
            'name' => 'separator_finance',
            'type' => 'custom_html',
            'value' => '<div class="alert alert-info"><strong>Finance Details</strong></div>',
        ]);

        CRUD::addField([
            'name' => 'fin_mode',
            'type' => 'select_from_array',
            'options' => ['Cash' => 'Cash', 'Finance' => 'Finance'],
            'label' => 'Finance Mode *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'fin_mode',
                'class' => 'form-control form-control-lg',
                'onchange' => 'toggleFinanceFields()'
            ]
        ]);

        CRUD::addField([
            'name' => 'financier',
            'type' => 'select',
            'label' => 'Financier',
            'model' => 'App\Models\XlFinancier',
            'attribute' => 'name',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'financier_wrapper'],
            'attributes' => [
                'id' => 'financier',
                'class' => 'form-control form-control-lg select2',
                'onchange' => 'updateFinancierShortName()'
            ]
        ]);

        CRUD::addField([
            'name' => 'financier_short_name',
            'type' => 'text',
            'label' => 'Financier Short Name',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'financier_short_name_wrapper'],
            'attributes' => [
                'id' => 'financier_short_name',
                'class' => 'form-control form-control-lg',
                'readonly' => 'readonly'
            ]
        ]);

        CRUD::addField([
            'name' => 'loan_status',
            'type' => 'select_from_array',
            'options' => ['Pending' => 'Pending', 'Approved' => 'Approved', 'Rejected' => 'Rejected'],
            'label' => 'Loan Status',
            'wrapper' => ['class' => 'form-group col-md-3', 'id' => 'loan_status_wrapper'],
            'attributes' => [
                'id' => 'loan_status',
                'class' => 'form-control form-control-lg'
            ]
        ]);

        // ============================================================
        // SECTION 7: BOOKING TYPE & SOURCE
        // ============================================================
        CRUD::addField([
            'name' => 'separator_source',
            'type' => 'custom_html',
            'value' => '<div class="alert alert-info"><strong>Booking Type & Source</strong></div>',
        ]);

        CRUD::addField([
            'name' => 'booking_source',
            'type' => 'select_from_array',
            'options' => [
                'Showroom' => 'Showroom',
                'Call' => 'Call',
                'Website' => 'Website',
                'Social Media' => 'Social Media',
                'Walk In' => 'Walk In',
                'Other' => 'Other'
            ],
            'label' => 'Booking Source',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'booking_source',
                'class' => 'form-control form-control-lg'
            ]
        ]);

        CRUD::addField([
            'name' => 'location',
            'type' => 'select_from_array',
            'options' => $this->getBranchOptions(),
            'label' => 'Branch / Location *',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'location',
                'class' => 'form-control form-control-lg'
            ]
        ]);

        CRUD::addField([
            'name' => 'location_other',
            'type' => 'text',
            'label' => 'Other Location',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'location_other',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Specify location'
            ]
        ]);

        CRUD::addField([
            'name' => 'delivery_type',
            'type' => 'select_from_array',
            'options' => [
                'Home Delivery' => 'Home Delivery',
                'Showroom Pickup' => 'Showroom Pickup',
                'Customer Pickup' => 'Customer Pickup'
            ],
            'label' => 'Delivery Type',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'delivery_type',
                'class' => 'form-control form-control-lg'
            ]
        ]);

        CRUD::addField([
            'name' => 'saleconsultant',
            'type' => 'select',
            'label' => 'Sale Consultant',
            'model' => 'App\Models\User',
            'attribute' => 'name',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'saleconsultant',
                'class' => 'form-control form-control-lg select2'
            ]
        ]);

        CRUD::addField([
            'name' => 'user',
            'type' => 'select',
            'label' => 'User',
            'model' => 'App\Models\User',
            'attribute' => 'name',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'user',
                'class' => 'form-control form-control-lg select2'
            ]
        ]);

        // ============================================================
        // SECTION 8: ADDITIONAL DETAILS
        // ============================================================
        CRUD::addField([
            'name' => 'separator_additional',
            'type' => 'custom_html',
            'value' => '<div class="alert alert-info"><strong>Additional Details</strong></div>',
        ]);

        CRUD::addField([
            'name' => 'buyer_type',
            'type' => 'select_from_array',
            'options' => ['Individual' => 'Individual', 'Corporate' => 'Corporate'],
            'label' => 'Buyer Type',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'buyer_type',
                'class' => 'form-control form-control-lg'
            ]
        ]);

        CRUD::addField([
            'name' => 'refrence_no',
            'type' => 'text',
            'label' => 'Reference No.',
            'wrapper' => ['class' => 'form-group col-md-3'],
            'attributes' => [
                'id' => 'refrence_no',
                'class' => 'form-control form-control-lg',
                'placeholder' => 'Reference number'
            ]
        ]);

        CRUD::addField([
            'name' => 'details',
            'type' => 'textarea',
            'label' => 'Additional Details / Notes',
            'wrapper' => ['class' => 'form-group col-md-12'],
            'attributes' => [
                'id' => 'details',
                'class' => 'form-control form-control-lg',
                'rows' => 4,
                'placeholder' => 'Any additional notes...'
            ]
        ]);

        // Hidden fields
        CRUD::addField([
            'name' => 'hidden_booking_date',
            'type' => 'hidden',
        ]);

        CRUD::addField([
            'name' => 'hidden_customer_dob',
            'type' => 'hidden',
        ]);

        CRUD::addField([
            'name' => 'hidden_receipt_date',
            'type' => 'hidden',
        ]);

        CRUD::addField([
            'name' => 'hidden_expected_del_date',
            'type' => 'hidden',
        ]);
    }

    /**
     * Perform any database calls required to display the edit form.
     */
    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }

    /**
     * Get branch options for dropdown
     */
    private function getBranchOptions()
    {
        $branches = CommonHelper::getBranches();
        $options = [];
        foreach ($branches as $branch) {
            $options[$branch['id']] = $branch['name'];
        }
        return $options;
    }
}
